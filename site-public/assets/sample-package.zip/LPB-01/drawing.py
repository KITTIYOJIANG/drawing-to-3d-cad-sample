"""Create the original, dimensioned revision-A source drawing (PDF + DXF)."""
from pathlib import Path

import ezdxf
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A3, landscape
from reportlab.pdfgen import canvas

OUT = Path(__file__).resolve().parent / "output"
OUT.mkdir(exist_ok=True)
W, H = landscape(A3)
S = 4.0  # drawing scale: 4 PDF points per model millimetre
INK = HexColor("#17283e")
BLUE = HexColor("#2164a2")
GREY = HexColor("#67788b")


def line(c, x1, y1, x2, y2, color=INK, width=1):
    c.setStrokeColor(color); c.setLineWidth(width); c.line(x1, y1, x2, y2)


def label(c, value, x, y, size=10, color=INK, font="Helvetica"):
    c.setFillColor(color); c.setFont(font, size); c.drawString(x, y, value)


def arrow(c, x, y, direction):
    d = 7 * direction
    line(c, x, y, x+d, y+3, BLUE, 0.9)
    line(c, x, y, x+d, y-3, BLUE, 0.9)


def hdim(c, x1, x2, feature_y, dim_y, txt):
    line(c, x1, feature_y, x1, dim_y + (-8 if dim_y < feature_y else 8), GREY, .55)
    line(c, x2, feature_y, x2, dim_y + (-8 if dim_y < feature_y else 8), GREY, .55)
    line(c, x1, dim_y, x2, dim_y, BLUE, .75)
    arrow(c, x1, dim_y, 1); arrow(c, x2, dim_y, -1)
    c.setFont("Helvetica", 9); c.setFillColor(BLUE)
    c.drawCentredString((x1+x2)/2, dim_y+5, txt)


def vdim(c, y1, y2, feature_x, dim_x, txt):
    line(c, feature_x, y1, dim_x+(-8 if dim_x < feature_x else 8), y1, GREY, .55)
    line(c, feature_x, y2, dim_x+(-8 if dim_x < feature_x else 8), y2, GREY, .55)
    line(c, dim_x, y1, dim_x, y2, BLUE, .75)
    line(c, dim_x, y1, dim_x-3, y1+7, BLUE, .75)
    line(c, dim_x, y1, dim_x+3, y1+7, BLUE, .75)
    line(c, dim_x, y2, dim_x-3, y2-7, BLUE, .75)
    line(c, dim_x, y2, dim_x+3, y2-7, BLUE, .75)
    c.saveState(); c.translate(dim_x-5, (y1+y2)/2); c.rotate(90)
    c.setFont("Helvetica", 9); c.setFillColor(BLUE); c.drawCentredString(0, 0, txt); c.restoreState()


def center(c, x, y, r=10):
    line(c, x-r, y, x+r, y, GREY, .5); line(c, x, y-r, x, y+r, GREY, .5)


def section_header(c, title, x, y, width):
    line(c, x, y, x+width, y, BLUE, 1.2)
    label(c, title, x, y+8, 12, INK, "Helvetica-Bold")


def make_pdf():
    path = OUT / "LPB-01_source_drawing_revA.pdf"
    c = canvas.Canvas(str(path), pagesize=(W, H))
    c.setTitle("LPB-01 Two-piece locating pin bracket - dimensioned source drawing Rev A")
    c.setAuthor("Drawing to CAD sample")
    c.setStrokeColor(INK); c.setLineWidth(1)
    c.rect(30, 30, W-60, H-60)
    label(c, "LPB-01  |  LOCATING-PIN MOUNTING BRACKET", 52, H-70, 21, INK, "Helvetica-Bold")
    label(c, "ORIGINAL STRUCTURED 2D DRAWING  /  REV A  /  ALL DIMENSIONS IN mm", 52, H-92, 10, GREY)
    line(c, 52, H-108, W-52, H-108, BLUE, 1.5)

    # Bracket front: view along -Y; X across and Z up.
    fx, fy = 130, 438
    section_header(c, "01  BRACKET FRONT  (X-Z)", 105, 675, 355)
    p = c.beginPath(); p.moveTo(fx,fy); p.lineTo(fx+80*S,fy); p.lineTo(fx+80*S,fy+6*S)
    p.lineTo(fx+6*S,fy+6*S); p.lineTo(fx+6*S,fy+50*S); p.lineTo(fx,fy+50*S); p.close()
    c.setStrokeColor(INK); c.setLineWidth(1.6); c.drawPath(p)
    # bore hidden lines in front view
    c.setDash(3,3)
    for z in (30-5.1, 30+5.1): line(c, fx, fy+z*S, fx+6*S, fy+z*S, GREY, .7)
    c.setDash()
    hdim(c, fx, fx+80*S, fy, 395, "80")
    hdim(c, fx, fx+6*S, fy+50*S, 657, "6")
    vdim(c, fy, fy+50*S, fx, 89, "50")
    vdim(c, fy, fy+6*S, fx+80*S, 474, "6")
    label(c, "Upright bore axis Z = 30", 282, 625, 9, BLUE)

    # Top view: X across and Y up. Through holes are visible.
    tx, ty = 130, 180
    section_header(c, "02  BRACKET TOP  (X-Y)", 105, 365, 355)
    c.setStrokeColor(INK); c.setLineWidth(1.5); c.rect(tx,ty,80*S,40*S)
    line(c, tx+6*S, ty, tx+6*S, ty+40*S, INK, 1)
    for x in (25,65):
        c.setStrokeColor(INK); c.setLineWidth(1.2); c.circle(tx+x*S,ty+20*S,3.3*S)
        center(c,tx+x*S,ty+20*S,19)
    hdim(c, tx, tx+25*S, ty, 152, "25")
    hdim(c, tx+25*S, tx+65*S, ty, 130, "40")
    hdim(c, tx+65*S, tx+80*S, ty, 152, "15")
    vdim(c, ty, ty+40*S, tx, 96, "40")
    vdim(c, ty, ty+20*S, tx+80*S, 474, "20")
    line(c, tx+65*S+10, ty+20*S+10, 390, 338, BLUE, .8)
    label(c, "2X DIA 6.6 THRU", 392, 343, 10, BLUE, "Helvetica-Bold")

    # Right-side view: Y across, Z up; bore appears as a circle.
    sx, sy = 610, 438
    section_header(c, "03  BRACKET RIGHT SIDE  (Y-Z)", 570, 675, 285)
    c.setStrokeColor(INK); c.setLineWidth(1.5); c.rect(sx,sy,40*S,50*S)
    line(c, sx, sy+6*S, sx+40*S, sy+6*S, INK, 1)
    c.circle(sx+20*S,sy+30*S,5.1*S)
    center(c,sx+20*S,sy+30*S,28)
    hdim(c,sx,sx+20*S,sy,415,"20")
    hdim(c,sx+20*S,sx+40*S,sy,415,"20")
    vdim(c,sy,sy+30*S,sx+40*S,803,"30")
    line(c,sx+20*S+15,sy+30*S+15,800,610,BLUE,.8)
    label(c,"DIA 10.2 THRU",797,616,10,BLUE,"Helvetica-Bold")

    # Pin detail, X axis horizontal; neck and head have separate dimensions.
    px, py = 610, 280
    section_header(c, "04  PIN DETAIL  (X-Z)", 570, 365, 285)
    c.setStrokeColor(INK); c.setLineWidth(1.5)
    p=c.beginPath(); p.moveTo(px-3*S,py-8*S); p.lineTo(px,py-8*S)
    p.lineTo(px,py-5*S); p.lineTo(px+48*S,py-5*S)
    p.lineTo(px+48*S,py+5*S); p.lineTo(px,py+5*S)
    p.lineTo(px,py+8*S); p.lineTo(px-3*S,py+8*S); p.close(); c.drawPath(p)
    line(c,px-25,py,px+48*S+15,py,GREY,.5)
    hdim(c,px,px+48*S,py-5*S,220,"48 UNDER HEAD")
    hdim(c,px-3*S,px,py+8*S,337,"3")
    vdim(c,py-5*S,py+5*S,px+48*S,830,"DIA 10")
    vdim(c,py-8*S,py+8*S,px-3*S,565,"DIA 16")

    # Exact dimension inventory and engineering boundary.
    section_header(c,"DIMENSION REGISTER",880,675,255)
    rows=[
        ("Bracket envelope","80 x 40 x 50"),
        ("Base / upright thickness","6 / 6"),
        ("Mount holes","2 x DIA 6.6 THRU"),
        ("Mount centers (X,Y)","(25,20), (65,20)"),
        ("Upright bore","DIA 10.2 THRU X"),
        ("Bore center (Y,Z)","(20,30)"),
        ("Pin shaft","DIA 10 x 48"),
        ("Pin head","DIA 16 x 3"),
        ("Assembly clearance","0.2 diametral nominal"),
    ]
    y=646
    for a,b in rows:
        label(c,a,887,y,8.6,GREY); label(c,b,887,y-14,9.5,INK,"Helvetica-Bold")
        line(c,887,y-20,1130,y-20,HexColor("#d9e1e9"),.5); y-=43
    label(c,"TECHNICAL NOTES",887,245,11,INK,"Helvetica-Bold")
    for i,t in enumerate([
        "1. Sharp edges shown; deburr for manufacture.",
        "2. Material, finish, GD&T and tolerances TBD.",
        "3. DIA 10.2 / DIA 10 is illustrative fit only.",
        "4. Verify missing or conflicting client dimensions",
        "   before production modeling or quotation.",
    ]): label(c,t,887,224-17*i,8.2,INK)
    line(c,52,95,W-52,95,BLUE,1.1)
    label(c,"PARTS: 1 bracket + 1 pin  |  GEOMETRY: revision A  |  PURPOSE: portfolio demonstrator",52,73,9,INK)
    label(c,"SCALE: indicative; use written dimensions",52,55,8,GREY)
    c.save()
    return path


def make_dxf():
    doc=ezdxf.new("R2010",setup=True)
    doc.header["$INSUNITS"]=4
    for name,color in (("OUTLINE",7),("CENTER",8),("DIMENSION",5),("NOTES",3)):
        doc.layers.new(name,dxfattribs={"color":color})
    m=doc.modelspace()
    m.add_lwpolyline([(0,0),(80,0),(80,6),(6,6),(6,50),(0,50)],close=True,dxfattribs={"layer":"OUTLINE"})
    m.add_text("FRONT X-Z",dxfattribs={"height":3,"insert":(0,55),"layer":"NOTES"})
    m.add_lwpolyline([(0,-90),(80,-90),(80,-50),(0,-50)],close=True,dxfattribs={"layer":"OUTLINE"})
    m.add_line((6,-90),(6,-50),dxfattribs={"layer":"OUTLINE"})
    for x in (25,65):
        m.add_circle((x,-70),3.3,dxfattribs={"layer":"OUTLINE"})
        m.add_line((x-5,-70),(x+5,-70),dxfattribs={"layer":"CENTER"})
    m.add_text("TOP X-Y: 80 x 40; 2X DIA 6.6 at (25,20),(65,20)",dxfattribs={"height":2.5,"insert":(0,-98),"layer":"NOTES"})
    m.add_lwpolyline([(105,0),(145,0),(145,50),(105,50)],close=True,dxfattribs={"layer":"OUTLINE"})
    m.add_line((105,6),(145,6),dxfattribs={"layer":"OUTLINE"})
    m.add_circle((125,30),5.1,dxfattribs={"layer":"OUTLINE"})
    m.add_text("RIGHT Y-Z: DIA 10.2 at Y20 Z30",dxfattribs={"height":2.5,"insert":(105,55),"layer":"NOTES"})
    m.add_lwpolyline([(102,-65),(105,-65),(105,-62),(153,-62),(153,-52),(105,-52),(105,-49),(102,-49)],close=True,dxfattribs={"layer":"OUTLINE"})
    m.add_text("PIN: DIA 10 x 48; HEAD DIA 16 x 3",dxfattribs={"height":2.5,"insert":(102,-80),"layer":"NOTES"})
    m.add_text("REV A; mm; dimensions and notes in companion PDF govern",dxfattribs={"height":2.5,"insert":(0,-115),"layer":"NOTES"})
    path=OUT/"LPB-01_source_geometry_revA.dxf"; doc.saveas(path)
    reloaded=ezdxf.readfile(path)
    assert reloaded.header["$INSUNITS"] == 4
    assert len(reloaded.modelspace()) >= 14
    return path


if __name__=="__main__":
    print(make_pdf()); print(make_dxf())
