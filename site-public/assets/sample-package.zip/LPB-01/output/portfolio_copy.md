# 作品介绍 / Portfolio copy

## Contra（英文，可直接发布）

**Title:** Dimensioned 2D Drawing to 3D CAD | Locating-Pin Bracket

**Summary:** I designed a fully dimensioned 2D drawing for a two-piece locating-pin mounting bracket, then built matching parametric solids in Python and CadQuery. The deliverables include a CAD-compatible STEP assembly, separate STEP and STL parts, orthographic and isometric previews, and a dimension-by-dimension verification report.

**What I did:** I defined the 80 × 40 × 50 mm bracket, two Ø6.6 mounting holes, Ø10.2 pin bore and Ø10 pin. I checked hole centers and diameters in the native CAD geometry, then re-imported the STEP parts to compare bounding boxes and volumes. The 20-second comparison video shows the path from the source drawing to the 3D result.

**Client value:** Clear, dimensioned engineering inputs become reviewable CAD files and a traceable handoff. For real projects, I flag missing dimensions, contradictory callouts and unspecified tolerances for human confirmation before final modeling. I do not claim automatic precision from blurry scans or photos.

**Tools / deliverables:** Python, CadQuery, STEP, STL, PDF, DXF, Blender, dimension check report.

**Suggested caption:** From a structured 2D engineering drawing to a checked 3D STEP assembly. Source dimensions, CAD solids and export checks are shown side by side.

## 国内客户（中文，可直接发布）

**标题：**二维工程图转三维 CAD｜插销安装支架建模样品

**简介：**我先绘制了一张尺寸完整的两件式插销安装支架工程图，再用 Python + CadQuery 建立参数化三维模型。交付包括装配及零件 STEP、零件 STL、正视/侧视/等轴测展示图，以及逐项尺寸一致性报告。

**样品亮点：**支架外形 80 × 40 × 50 mm，包含两个 Ø6.6 安装孔、Ø10.2 插销孔和 Ø10 插销。对原生 CAD 的孔径、孔位和外形进行了检查，并回读 STEP 对照体积与包围盒。20 秒演示视频展示从原始二维图纸到三维结果的过程。

**合作方式：**适合尺寸明确的 PDF/DXF 图纸转 3D 建模、STEP/STL 输出和工程图整理。缺尺寸、标注冲突、无法确认的公差会先列问题清单，请客户确认后建模；模糊扫描件或照片不承诺全自动精确转换。

**展示文案：**从尺寸明确的二维图纸，到可检查的三维 STEP 装配；输入、模型和尺寸结果并排呈现。
