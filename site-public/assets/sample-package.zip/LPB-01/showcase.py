"""Assemble three rendered CAD views into a client-facing technical display."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT=Path(__file__).resolve().parent/"output"
FONT=Path(r"C:\Windows\Fonts\arial.ttf")
BOLD=Path(r"C:\Windows\Fonts\arialbd.ttf")


def f(size,bold=False):
    return ImageFont.truetype(str(BOLD if bold else FONT),size)


def paste_render(canvas,name,box):
    im=Image.open(OUT/f"{name}_render.png").convert("RGBA")
    bb=im.getchannel("A").getbbox()
    im=im.crop(bb)
    x0,y0,x1,y1=box
    scale=min((x1-x0)/im.width,(y1-y0)/im.height)
    im=im.resize((int(im.width*scale),int(im.height*scale)),Image.Resampling.LANCZOS)
    x=int((x0+x1-im.width)/2); y=int((y0+y1-im.height)/2)
    canvas.alpha_composite(im,(x,y))


def make():
    im=Image.new("RGBA",(2400,1500),(246,249,253,255))
    d=ImageDraw.Draw(im)
    navy=(21,42,68); blue=(33,100,162); grey=(105,122,144)
    d.rectangle((0,0,2400,20),fill=blue)
    d.text((110,85),"2D DRAWING  →  3D CAD",font=f(71,True),fill=navy)
    d.text((113,178),"LPB-01  /  TWO-PIECE LOCATING-PIN BRACKET  /  REV A",font=f(29),fill=grey)
    cards=[(100,285,1420,1240),(1460,285,2290,745),(1460,780,2290,1240)]
    for box in cards:
        d.rounded_rectangle(box,radius=34,fill="white",outline=(216,226,237),width=3)
    d.text((150,330),"ISOMETRIC  /  ASSEMBLY",font=f(30,True),fill=navy)
    d.text((1510,330),"FRONT  /  X-Z",font=f(28,True),fill=navy)
    d.text((1510,825),"SIDE  /  Y-Z",font=f(28,True),fill=navy)
    paste_render(im,"isometric",(155,390,1360,1170))
    paste_render(im,"front",(1515,390,2235,700))
    paste_render(im,"side",(1540,885,2200,1190))
    d.line((100,1320,2290,1320),fill=(202,215,230),width=3)
    d.text((110,1350),"BASE 80 × 40 × 6 mm",font=f(28,True),fill=navy)
    d.text((595,1350),"HEIGHT 50 mm",font=f(28,True),fill=navy)
    d.text((1010,1350),"2 × Ø6.6 THRU",font=f(28,True),fill=navy)
    d.text((1470,1350),"Ø10.2 BORE  /  Ø10 PIN",font=f(28,True),fill=navy)
    d.text((110,1420),"Structured source drawing • CadQuery solids • STEP + STL • nominal 0.2 mm diametral clearance",font=f(24),fill=grey)
    path=OUT/"technical_showcase.png"; im.convert("RGB").save(path,optimize=True)
    return path


if __name__=="__main__": print(make())
