"""Render orthographic and isometric views from the exported CAD meshes.

Run in Blender: blender -b --python render_blender.py
"""
from pathlib import Path
import bpy
from mathutils import Vector

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"output"

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene
scene.render.engine="BLENDER_EEVEE"
scene.render.resolution_x=1400
scene.render.resolution_y=1000
scene.render.resolution_percentage=100
scene.render.image_settings.file_format="PNG"
scene.render.film_transparent=True
scene.render.engine="BLENDER_EEVEE"
scene.render.resolution_percentage=100
scene.world.color=(0.8,0.8,0.8)
scene.world.use_nodes=True
scene.world.node_tree.nodes["Background"].inputs["Color"].default_value=(0.75,0.82,0.9,1)
scene.world.node_tree.nodes["Background"].inputs["Strength"].default_value=1.0
scene.view_settings.view_transform="Standard"
scene.view_settings.look="Medium High Contrast"


def mat(name,color,metallic):
    m=bpy.data.materials.new(name)
    m.diffuse_color=(*color,1)
    m.use_nodes=True
    p=m.node_tree.nodes.get("Principled BSDF")
    p.inputs["Base Color"].default_value=(*color,1)
    p.inputs["Metallic"].default_value=metallic
    p.inputs["Roughness"].default_value=.38
    return m


for name,color,metallic in (("bracket",(.11,.32,.57),.35),("pin",(.95,.42,.12),.55)):
    bpy.ops.wm.stl_import(filepath=str(OUT/f"{name}.stl"))
    obj=bpy.context.object
    obj.name=name
    obj.data.materials.append(mat(name,color,metallic))


def point(obj,target):
    obj.rotation_euler=(Vector(target)-obj.location).to_track_quat("-Z","Y").to_euler()


def area(name,location,power,size,target):
    data=bpy.data.lights.new(name,"AREA")
    data.energy=power; data.shape="DISK"; data.size=size
    obj=bpy.data.objects.new(name,data); bpy.context.collection.objects.link(obj)
    obj.location=location; point(obj,target)


target=(38,20,26)
area("large key",(15,-65,125),170000,95,target)
area("soft fill",(115,85,85),120000,110,target)
area("rim",(-65,20,85),90000,80,target)

cam_data=bpy.data.cameras.new("orthographic camera")
cam=bpy.data.objects.new("orthographic camera",cam_data)
bpy.context.collection.objects.link(cam)
scene.camera=cam
cam_data.type="ORTHO"; cam_data.lens=50
cam_data.clip_end=2000

views={
    "front":((39,-130,27),(39,20,27),126),
    "side":((-135,20,27),(10,20,27),79),
    "isometric":((135,-140,115),(31,20,22),130),
}
for name,(position,look_at,scale) in views.items():
    cam.location=position; point(cam,look_at); cam_data.ortho_scale=scale
    scene.render.filepath=str(OUT/f"{name}_render.png")
    bpy.ops.render.render(write_still=True)
    print("RENDERED",scene.render.filepath)
