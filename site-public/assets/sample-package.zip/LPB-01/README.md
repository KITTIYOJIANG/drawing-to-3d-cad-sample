# LPB-01: Dimensioned 2D Drawing → 3D CAD Sample

原创两件式插销安装支架样品。输入是自制、结构化且标称尺寸明确的 Rev A 图纸；输出是 CadQuery 模型、STEP/STL、技术展示图、尺寸对比报告、20 秒演示视频和中英文作品文案。

## 交付入口

- [打包下载：客户样品 ZIP](output/LPB-01_client_sample.zip)
- [原始工程图 PDF](output/LPB-01_source_drawing_revA.pdf) 和 [二维 DXF 几何](output/LPB-01_source_geometry_revA.dxf)
- [装配 STEP](output/assembly.step)、[支架 STEP](output/bracket.step)、[插销 STEP](output/pin.step)
- [支架 STL](output/bracket.stl)、[插销 STL](output/pin.stl)
- [三视图技术展示](output/technical_showcase.png)、[等轴测渲染](output/isometric_render.png)
- [英文对比报告 PDF](output/LPB-01_comparison_report.pdf)、[中文详细报告](output/comparison_report.md)、[机器检查数据](output/geometry_checks.json)
- [20 秒演示视频](output/LPB-01_2D_to_3D_20s.mp4)、[作品介绍](output/portfolio_copy.md)、[试单报价](output/pilot_quote.md)

## 几何规格

坐标：X 为底板长度与插销轴向，Y 为宽度，Z 向上。支架外形 80 × 40 × 50 mm；底板与立板均厚 6 mm；安装孔 2 × Ø6.6，中心为 (X25,Y20)、(X65,Y20)；立板孔 Ø10.2，中心为 (Y20,Z30)；插销 Ø10 × 48（头下长度），头部 Ø16 × 3。全部单位为 mm。

## 复现

需要 Windows、Python 3.12、[uv](https://docs.astral.sh/uv/)、Blender 5.3 和 FFmpeg。进入此目录：

```powershell
uv venv --python 3.12 .venv
uv pip install --python .venv\Scripts\python.exe -r requirements.txt
.venv\Scripts\python.exe model.py
.venv\Scripts\python.exe drawing.py
& 'C:\Program Files\Blender Foundation\Blender 5.3\blender.exe' -b --python render_blender.py
.venv\Scripts\python.exe showcase.py
.venv\Scripts\python.exe make_video.py
.venv\Scripts\python.exe report_pdf.py
.venv\Scripts\python.exe package.py
```

`model.py` 对原生实体、STEP 回读、圆边孔位、装配零件数和 STL 包围盒进行程序检查。`video_check.json` 保存视频时长、帧率和帧数。图纸的名义尺寸并非制造公差或装配功能保证；材料、表面处理、配合等级、GD&T 等需客户确认。模糊 PDF、照片、缺失或矛盾标注不会自动推断成“精确模型”。
