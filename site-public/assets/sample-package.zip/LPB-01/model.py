"""Parametric, millimetre-based demonstrator for a two-piece locating-pin bracket.

Coordinates: X is the base length and pin axis, Y the width, Z upward.
All values are intentionally explicit so a structured drawing can be audited.
"""
from __future__ import annotations

import json
import math
import struct
from pathlib import Path

import cadquery as cq

HERE = Path(__file__).resolve().parent
OUT = HERE / "output"
OUT.mkdir(exist_ok=True)

D = {
    "base_length": 80.0,
    "width": 40.0,
    "base_thickness": 6.0,
    "overall_height": 50.0,
    "upright_thickness": 6.0,
    "mount_hole_diameter": 6.6,
    "mount_hole_x": [25.0, 65.0],
    "mount_hole_y": 20.0,
    "bore_diameter": 10.2,
    "bore_y": 20.0,
    "bore_z": 30.0,
    "pin_diameter": 10.0,
    "pin_length_under_head": 48.0,
    "head_diameter": 16.0,
    "head_thickness": 3.0,
}


def make_bracket() -> cq.Workplane:
    base = cq.Workplane("XY").box(80, 40, 6, centered=(False, False, False))
    upright = cq.Workplane("XY").box(6, 40, 44, centered=(False, False, False)).translate((0, 0, 6))
    part = base.union(upright)
    holes = cq.Workplane("XY").pushPoints([(25, 20), (65, 20)]).circle(3.3).extrude(6)
    bore = cq.Workplane("YZ", origin=(0, 20, 30)).circle(5.1).extrude(6)
    return part.cut(holes).cut(bore)


def make_pin() -> cq.Workplane:
    shaft = cq.Workplane("YZ", origin=(0, 20, 30)).circle(5).extrude(48)
    head = cq.Workplane("YZ", origin=(-3, 20, 30)).circle(8).extrude(3)
    return shaft.union(head)


def box_dims(shape):
    b = shape.BoundingBox()
    return [round(b.xlen, 6), round(b.ylen, 6), round(b.zlen, 6)]


def circular_edges(shape):
    return [
        {"radius": round(e.radius(), 4), "center": [round(v, 4) for v in e.Center().toTuple()]}
        for e in shape.Edges() if e.geomType() == "CIRCLE"
    ]


def stl_bbox(path):
    data = path.read_bytes()
    count = struct.unpack_from("<I", data, 80)[0]
    assert len(data) == 84 + count * 50, "Expected binary STL"
    bounds = [[math.inf, -math.inf] for _ in range(3)]
    for i in range(count):
        for j in range(3):
            point = struct.unpack_from("<fff", data, 84 + i * 50 + 12 + j * 12)
            for axis, value in enumerate(point):
                bounds[axis][0] = min(bounds[axis][0], value)
                bounds[axis][1] = max(bounds[axis][1], value)
    return [round(hi-lo, 4) for lo, hi in bounds]


def build():
    bracket, pin = make_bracket(), make_pin()
    bs, ps = bracket.val(), pin.val()
    assert box_dims(bs) == [80, 40, 50]
    assert box_dims(ps) == [51, 16, 16]
    expected_bracket = 80*40*6 + 6*40*44 - 2*math.pi*3.3**2*6 - math.pi*5.1**2*6
    expected_pin = math.pi*5**2*48 + math.pi*8**2*3
    assert abs(bs.Volume() - expected_bracket) < 0.01
    assert abs(ps.Volume() - expected_pin) < 0.01
    be, pe = circular_edges(bs), circular_edges(ps)
    assert sum(e["radius"] == 3.3 for e in be) == 4
    assert sum(e["radius"] == 5.1 for e in be) == 2
    assert sum(e["radius"] == 5.0 for e in pe) >= 1
    assert sum(e["radius"] == 8.0 for e in pe) >= 1
    for x in (25.0, 65.0):
        assert sum(e["radius"] == 3.3 and abs(e["center"][0]-x) < .001 and abs(e["center"][1]-20) < .001 for e in be) == 2
    assert sum(e["radius"] == 5.1 and abs(e["center"][1]-20) < .001 and abs(e["center"][2]-30) < .001 for e in be) == 2

    native_dims = {"bracket": box_dims(bs), "pin": box_dims(ps)}
    native_volume = {"bracket": bs.Volume(), "pin": ps.Volume()}
    cq.exporters.export(bracket, str(OUT / "bracket.step"))
    cq.exporters.export(pin, str(OUT / "pin.step"))
    assembly = cq.Assembly(name="LPB-01")
    assembly.add(bracket, name="bracket", color=cq.Color(0.13, 0.34, 0.58))
    assembly.add(pin, name="pin", color=cq.Color(0.92, 0.49, 0.17))
    assembly.save(str(OUT / "assembly.step"))
    assembly_import = cq.importers.importStep(str(OUT / "assembly.step"))
    assert len(assembly_import.solids().vals()) == 2

    imported = {name: cq.importers.importStep(str(OUT / f"{name}.step")).val() for name in ("bracket", "pin")}
    for name in ("bracket", "pin"):
        assert abs(imported[name].Volume() - native_volume[name]) < 0.01
        assert all(abs(a-b) < 0.001 for a, b in zip(box_dims(imported[name]), native_dims[name])), (name, box_dims(imported[name]), native_dims[name])
    # OCC tessellation can inflate the in-memory bounding-box tolerance; mesh last.
    cq.exporters.export(bracket, str(OUT / "bracket.stl"), tolerance=0.02, angularTolerance=0.1)
    cq.exporters.export(pin, str(OUT / "pin.stl"), tolerance=0.02, angularTolerance=0.1)
    for name in ("bracket", "pin"):
        assert all(abs(a-b) < 0.03 for a,b in zip(stl_bbox(OUT / f"{name}.stl"), native_dims[name]))

    checks = {
        "units": "mm",
        "drawing_revision": "A",
        "dimensions": D,
        "geometry": {
            "bracket": {"bbox_mm": native_dims["bracket"], "volume_mm3": round(native_volume["bracket"], 4), "step_roundtrip_volume_mm3": round(imported["bracket"].Volume(), 4)},
            "pin": {"bbox_mm": native_dims["pin"], "volume_mm3": round(native_volume["pin"], 4), "step_roundtrip_volume_mm3": round(imported["pin"].Volume(), 4)},
        },
        "nominal_diametral_clearance_mm": round(D["bore_diameter"] - D["pin_diameter"], 3),
        "assembly_step_solid_count": 2,
        "circular_edges": {"bracket": be, "pin": pe},
        "stl_bbox_mm": {name: stl_bbox(OUT / f"{name}.stl") for name in ("bracket", "pin")},
        "status": "PASS: native solids and STEP round-trip dimensions/volumes",
    }
    (OUT / "geometry_checks.json").write_text(json.dumps(checks, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(checks["geometry"], indent=2))


if __name__ == "__main__":
    build()
