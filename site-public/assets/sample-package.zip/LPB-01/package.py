"""Build a compact, reviewable sample archive without environment or QA files."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT=Path(__file__).resolve().parent
OUT=ROOT/"output"
FILES=[
    "README.md","requirements.txt","model.py","drawing.py","render_blender.py",
    "showcase.py","make_video.py","report_pdf.py","package.py",
    "output/LPB-01_source_drawing_revA.pdf","output/LPB-01_source_geometry_revA.dxf",
    "output/assembly.step","output/bracket.step","output/pin.step",
    "output/bracket.stl","output/pin.stl",
    "output/front_render.png","output/side_render.png","output/isometric_render.png",
    "output/technical_showcase.png","output/drawing_preview.png",
    "output/LPB-01_comparison_report.pdf","output/comparison_report.md",
    "output/geometry_checks.json","output/video_check.json",
    "output/LPB-01_2D_to_3D_20s.mp4","output/portfolio_copy.md","output/pilot_quote.md",
]


def make():
    target=OUT/"LPB-01_client_sample.zip"
    with ZipFile(target,"w",ZIP_DEFLATED,compresslevel=6) as archive:
        for name in FILES:
            path=ROOT/name
            assert path.is_file(),path
            archive.write(path,arcname=f"LPB-01/{name}")
    with ZipFile(target) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist())==len(FILES)
    print(target, target.stat().st_size, "bytes", len(FILES), "files")


if __name__=="__main__": make()
