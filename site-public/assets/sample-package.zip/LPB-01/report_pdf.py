"""Client-facing PDF report; the Chinese source report is comparison_report.md."""
from pathlib import Path
from PIL import Image
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfgen import canvas

OUT=Path(__file__).resolve().parent/"output"
W,H=landscape(A4)
NAVY=HexColor("#172c48"); BLUE=HexColor("#2164a2"); GREY=HexColor("#64788e")
PALE=HexColor("#e7f0f9")


def text(c,s,x,y,size=10,bold=False,color=NAVY):
    c.setFont("Helvetica-Bold" if bold else "Helvetica",size)
    c.setFillColor(color); c.drawString(x,y,s)


def header(c,number):
    c.setFillColor(BLUE); c.rect(0,H-8,W,8,fill=1,stroke=0)
    text(c,"LPB-01   |   2D DRAWING TO 3D CAD",38,H-45,17,True)
    text(c,"Dimension traceability report  /  Rev A  /  millimetres",39,H-63,9,False,GREY)
    c.setStrokeColor(HexColor("#cddce9")); c.line(38,38,W-38,38)
    text(c,"ORIGINAL CAD DEMONSTRATOR",39,23,8,False,GREY)
    text(c,f"{number} / 2",W-66,23,8,False,GREY)


def table(c,rows,x,y,width,row_height=28,col_widths=None):
    if col_widths is None: col_widths=[width/len(rows[0])]*len(rows[0])
    for i,row in enumerate(rows):
        yy=y-i*row_height
        c.setFillColor(PALE if i==0 else (HexColor("#f7fafd") if i%2 else HexColor("#ffffff")))
        c.rect(x,yy-row_height,width,row_height,fill=1,stroke=0)
        xx=x
        for j,value in enumerate(row):
            text(c,str(value),xx+8,yy-row_height+9,8 if i else 8.5,i==0,NAVY)
            xx+=col_widths[j]
    c.setStrokeColor(HexColor("#d5e1ed")); c.rect(x,y-len(rows)*row_height,width,len(rows)*row_height,fill=0,stroke=1)


def make():
    path=OUT/"LPB-01_comparison_report.pdf"
    c=canvas.Canvas(str(path),pagesize=(W,H))
    c.setTitle("LPB-01 Drawing-to-CAD Traceability Report Rev A")
    header(c,1)
    text(c,"SOURCE DRAWING",42,492,12,True,BLUE)
    text(c,"3D RESULT",435,492,12,True,BLUE)
    c.setStrokeColor(HexColor("#d5e1ed")); c.roundRect(38,204,370,279,12,stroke=1,fill=0)
    c.roundRect(430,204,374,279,12,stroke=1,fill=0)
    c.drawImage(str(OUT/"drawing_preview.png"),49,214,width=348,height=250,preserveAspectRatio=True,anchor="c")
    iso=Image.open(OUT/"isometric_render.png").convert("RGBA")
    bg=Image.new("RGBA",iso.size,"white"); bg.alpha_composite(iso)
    tmp=Path(__file__).resolve().parent/"tmp"; tmp.mkdir(exist_ok=True)
    flattened=tmp/"report_iso_white.png"; bg.convert("RGB").save(flattened)
    c.drawImage(str(flattened),440,215,width=352,height=251,preserveAspectRatio=True,anchor="c")
    text(c,"CHECK SUMMARY",40,179,12,True,BLUE)
    table(c,[
        ("Item","Drawing / CAD result","Status"),
        ("Bracket envelope","80 x 40 x 50 mm","MATCH"),
        ("Mounting holes","2 x DIA 6.6; centers (25,20), (65,20)","MATCH"),
        ("Pin bore / shaft","DIA 10.2 / DIA 10; nominal clearance 0.2","MATCH"),
    ],38,165,W-76,28,[165,480,121])
    c.showPage()
    header(c,2)
    text(c,"DIMENSION-BY-DIMENSION CHECK",39,490,13,True,BLUE)
    rows=[
        ("Feature","Rev A source","Native CAD / STEP check","Result"),
        ("Base and upright","80 x 40 x 50; t=6 each","Bounding box + analytic volume","PASS"),
        ("Mount holes","2 x DIA 6.6 THRU","R3.3 circular edges at X25/X65, Y20","PASS"),
        ("Upright bore","DIA 10.2; Y20, Z30","R5.1 end circles; centers Y20/Z30","PASS"),
        ("Pin shaft","DIA 10 x 48 under head","R5; X0 to X48","PASS"),
        ("Pin head","DIA 16 x 3","R8; X-3 to X0","PASS"),
        ("Pin envelope","51 x 16 x 16","Native + STEP round-trip box","PASS"),
        ("STL envelopes","Nominal geometry","Within 0.03 mm of native boxes","PASS"),
    ]
    table(c,rows,38,471,W-76,31,[126,183,344,113])
    text(c,"MEASURED SOLID VOLUME",40,198,10,True,BLUE)
    text(c,"Bracket 28,859.1797 mm3   |   Pin 4,373.0970 mm3",40,180,9,False,NAVY)
    text(c,"STEP re-import volumes match at 0.0001 mm3 reporting precision.",40,165,9,False,NAVY)
    text(c,"HUMAN CONFIRMATION REQUIRED FOR PRODUCTION",40,136,10,True,BLUE)
    notes=[
        "Material, finish, edge breaks, general tolerances, GD&T and fit class are unspecified.",
        "The 0.2 mm clearance is nominal only and is not a functional fit guarantee.",
        "Missing dimensions, conflicting callouts or illegible scans require client clarification.",
        "This is a structured-drawing demonstrator; arbitrary PDFs/photos are not auto-converted accurately.",
    ]
    for i,n in enumerate(notes): text(c,"- " + n,41,117-i*17,8.3,False,NAVY)
    c.save()
    return path


if __name__=="__main__": print(make())
