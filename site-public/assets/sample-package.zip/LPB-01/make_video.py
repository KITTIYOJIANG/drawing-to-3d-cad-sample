"""Create a 20-second, 25 fps, silent 2D-to-3D comparison MP4."""
from pathlib import Path
import json
import subprocess
from PIL import Image, ImageDraw, ImageFont

OUT=Path(__file__).resolve().parent/"output"
STILLS=OUT/"video_stills"
STILLS.mkdir(exist_ok=True)
F=Path(r"C:\Windows\Fonts\arial.ttf")
B=Path(r"C:\Windows\Fonts\arialbd.ttf")
SIZE=(1280,720)
NAVY=(18,39,64); BLUE=(37,105,169); GREY=(102,121,143)


def font(size,bold=False): return ImageFont.truetype(str(B if bold else F),size)


def base(kicker,title,subtitle):
    im=Image.new("RGB",SIZE,(246,249,253)); d=ImageDraw.Draw(im)
    d.rectangle((0,0,1280,12),fill=BLUE)
    d.text((64,44),kicker,font=font(19,True),fill=BLUE)
    d.text((64,75),title,font=font(47,True),fill=NAVY)
    d.text((66,139),subtitle,font=font(21),fill=GREY)
    d.line((64,674,1216,674),fill=(205,219,233),width=2)
    d.text((66,687),"LPB-01  /  REV A",font=font(15,True),fill=GREY)
    d.text((1021,687),"DRAWING TO CAD",font=font(15,True),fill=GREY)
    return im


def card(d,box): d.rounded_rectangle(box,radius=24,fill="white",outline=(212,224,236),width=2)


def fit(im,path,box,alpha=False):
    src=Image.open(path).convert("RGBA" if alpha else "RGB")
    if alpha: src=src.crop(src.getchannel("A").getbbox())
    x0,y0,x1,y1=box
    ratio=min((x1-x0)/src.width,(y1-y0)/src.height)
    src=src.resize((int(src.width*ratio),int(src.height*ratio)),Image.Resampling.LANCZOS)
    pos=(int((x0+x1-src.width)/2),int((y0+y1-src.height)/2))
    if alpha:
        rgba=im.convert("RGBA"); rgba.alpha_composite(src,pos); im.paste(rgba.convert("RGB"))
    else: im.paste(src,pos)


def slides():
    drawing=OUT/"drawing_preview.png"
    if not drawing.exists():
        import fitz
        page=fitz.open(OUT/"LPB-01_source_drawing_revA.pdf")[0]
        page.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False).save(drawing)
    # 01: input drawing
    im=base("01 / STRUCTURED INPUT","A dimensioned 2D drawing","Original bracket and pin design · PDF + DXF · all units in mm")
    d=ImageDraw.Draw(im); card(d,(65,190,1215,640)); fit(im,drawing,(87,205,1193,624))
    im.save(STILLS/"01_drawing.png")
    # 02: direct comparison
    im=base("02 / GEOMETRY TRANSFER","From lines to solids","One explicit dimension set drives both the drawing and the CadQuery model")
    d=ImageDraw.Draw(im); card(d,(65,198,608,632)); card(d,(673,198,1215,632))
    fit(im,drawing,(82,220,592,585)); fit(im,OUT/"isometric_render.png",(686,223,1201,600),True)
    d=ImageDraw.Draw(im); d.text((237,597),"2D SOURCE",font=font(22,True),fill=NAVY)
    d.text((822,597),"3D ASSEMBLY",font=font(22,True),fill=NAVY)
    d.rounded_rectangle((607,392,674,449),radius=20,fill=BLUE)
    d.text((620,399),"→",font=font(41,True),fill="white")
    im.save(STILLS/"02_comparison.png")
    # 03: three-dimensional deliverable
    im=base("03 / CAD RESULT","CAD STEP + STL meshes","Bracket and pin as separate parts, plus an assembled STEP file")
    d=ImageDraw.Draw(im); card(d,(65,190,880,640)); fit(im,OUT/"isometric_render.png",(89,211,856,622),True)
    for y,txt in ((245,"80 × 40 × 50 mm bracket"),(332,"2 × Ø6.6 mounting holes"),(419,"Ø10.2 bore / Ø10 pin"),(506,"0.2 mm nominal clearance")):
        d.rounded_rectangle((915,y,1215,y+65),radius=16,fill=(232,241,250))
        d.text((935,y+17),txt,font=font(21,True),fill=NAVY)
    im.save(STILLS/"03_model.png")
    # 04: checked handoff
    im=base("04 / VERIFIED HANDOFF","Three views. Checked dimensions.","Front · side · isometric views with STEP re-import and STL envelope checks")
    d=ImageDraw.Draw(im); card(d,(65,190,815,640)); fit(im,OUT/"technical_showcase.png",(82,211,798,617))
    d.rounded_rectangle((845,208,1215,625),radius=24,fill=(231,241,251))
    for y,head,value in ((239,"BRACKET ENVELOPE","80 × 40 × 50"),(329,"MOUNT HOLES","2 × Ø6.6"),(419,"PIN SHAFT","Ø10 × 48"),(509,"STEP ROUND-TRIP","PASS")):
        d.text((872,y),head,font=font(18,True),fill=BLUE)
        d.text((872,y+31),value,font=font(26,True),fill=NAVY)
    im.save(STILLS/"04_verified.png")


def encode():
    files=[STILLS/f"{n}.png" for n in ("01_drawing","02_comparison","03_model","04_verified")]
    args=["ffmpeg","-y","-hide_banner","-loglevel","error"]
    for file in files: args += ["-loop","1","-framerate","25","-t","5.75","-i",str(file)]
    graph=("[0:v][1:v]xfade=transition=wipeleft:duration=1:offset=4.75[v1];"
           "[v1][2:v]xfade=transition=fade:duration=1:offset=9.5[v2];"
           "[v2][3:v]xfade=transition=fade:duration=1:offset=14.25,format=yuv420p[v]")
    target=OUT/"LPB-01_2D_to_3D_20s.mp4"
    args += ["-filter_complex",graph,"-map","[v]","-t","20","-r","25","-c:v","libx264","-preset","medium","-crf","18","-pix_fmt","yuv420p","-movflags","+faststart",str(target)]
    subprocess.run(args,check=True)
    probe=subprocess.run(["ffprobe","-v","error","-show_entries","format=duration:stream=width,height,r_frame_rate,nb_frames","-of","json",str(target)],check=True,capture_output=True,text=True)
    info=json.loads(probe.stdout)
    (OUT/"video_check.json").write_text(json.dumps(info,indent=2),encoding="utf-8")
    print(target,info)


if __name__=="__main__":
    slides(); encode()
